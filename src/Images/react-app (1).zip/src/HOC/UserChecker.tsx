import React, { FC } from 'react'

import { Navigate, useLocation } from "react-router-dom";
import { IUser } from "../models";
interface ILocationState {
    user?: IUser
}

const UserChecker: FC<{ children: React.ReactNode | null }> = ({ children }): JSX.Element | null => {
    const location = useLocation()
    const locationState = location?.state as ILocationState

    if (!locationState?.user) {
        return <Navigate to='/users' />
    }
    return (
        <>{children}</>
    )
}

export default UserChecker