

import { Routes, Route, Link } from 'react-router-dom'
import UsersPage from "./pages/UsersPage";

import './style/main.scss'
import SingleUserPage from './pages/SingleUserPage';
import UserChecker from './HOC/UserChecker';

function App() {

  return (
    <>
      <header className="header">
        <nav>
          <ul>
            <li><Link to="/users">users</Link></li>
            <li><Link to="/about">about</Link></li>
            <li><Link to="/contact">contact</Link></li>
          </ul>
        </nav>
      </header>
      <Routes>
        <Route path="/users" element={<UsersPage />} />
        <Route path="/users/:id" element={
          <UserChecker>
            <SingleUserPage />
          </UserChecker>
        } />
        <Route path="/about" element={<div>about</div>} />
        <Route path="/contact" element={<div>contact</div>} />
        <Route path="*" element={<div>error</div>} />
      </Routes>
    </>
  );
}

export default App;