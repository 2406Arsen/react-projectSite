import { FC } from "react"
import { IUsersProps } from "../../models"
import User from "./UserCart/UserCart"

const Users: FC<IUsersProps> = ({ users }) => {

    return (
        <div className='users'>
            {/* <form action="submit" onSubmit={(e) => {
                e.preventDefault()
                e.stopPropagation()
            }}>
                <button type="submit">submit button </button>
            </form> */}
            {users.map((user) => <User user={user} key={`${user.phone}${user.name}`} />)}
        </div>
    )
}

export default Users