import { useLocation } from "react-router-dom"
import UserCart from "../components/Users/UserCart/UserCart"
import { IUser } from "../models"

interface ILocationState {
    user?: IUser
}

const SingleUserPage = () => {
    const location = useLocation()
    const locationState = location.state as ILocationState

    return (
        <UserCart user={locationState?.user!} />
    )
}

export default SingleUserPage