import Users from "../components/Users/Users"
import { users } from "../users.data"

const UsersPage = () => {
    return (
        <Users users={users} />
    )
}

export default UsersPage