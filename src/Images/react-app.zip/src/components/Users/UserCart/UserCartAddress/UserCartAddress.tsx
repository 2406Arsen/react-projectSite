import { FC } from "react"
import { IAddressProps } from "../../../../models"

const UserCartAddress: FC<IAddressProps> = ({ address, country, postalZip, region }) => {
    return (
        <ul className="userCartAddress">
            <li>{address}</li>
            <li>{country}</li>
            <li>{postalZip}</li>
            <li>{region}</li>
        </ul>
    )
}

export default UserCartAddress