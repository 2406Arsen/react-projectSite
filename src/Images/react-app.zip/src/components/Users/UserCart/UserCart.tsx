import React, { FC, useEffect, useRef, useState } from "react"
// import { useParams } from "react-router-dom"
import { ATTRIBUTE_VALUES, IUser, IUserCartProps } from "../../../models"
import UserCartAddress from "./UserCartAddress/UserCartAddress"



const User: FC<IUserCartProps> = ({ user }) => {
  // const params = useParams()

  const [userData, setUserData] = useState(user)
  const [currentFieldName, setCurrentFieldName] = useState('')
  const [inputValue, setInputValue] = useState('')
  const isMounted = useRef(false)
  let inputRef = useRef<HTMLInputElement>(null)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputValue(e.target.value);
  }

  const handleChangeUserData = (e: React.MouseEvent<HTMLElement>): void => {
    setInputValue('')
    inputRef?.current?.focus()

    const fieldName = e.currentTarget.getAttribute('data-fieldname')! as keyof IUser
    setCurrentFieldName(fieldName)

  }


  useEffect(() => {
    if (isMounted.current) {
      if (inputValue.length !== 0) {
        setUserData((prev) => ({
          ...prev,
          [currentFieldName]: inputValue
        }))
      }
    } else {
      isMounted.current = true
    }

  }, [inputValue, currentFieldName])




  return (
    <div className='userCart' >
      <h5 data-fieldname={ATTRIBUTE_VALUES.NAME} onClick={handleChangeUserData} >{userData.name}</h5>
      <p data-fieldname={ATTRIBUTE_VALUES.EMAIL} onClick={handleChangeUserData}>{userData.email}</p>
      <span data-fieldname={ATTRIBUTE_VALUES.POSTAL_ZIP} onClick={handleChangeUserData} >{userData.postalZip}</span>
      <UserCartAddress address={userData.address} country={userData.country} postalZip={userData.postalZip} region={userData.region} />
      <input
        type="text"
        placeholder="placeholder..."
        onChange={handleChange}
        ref={inputRef}
        value={inputValue}
      />

    </div>
  )
}

export default User