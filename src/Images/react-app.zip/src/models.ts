export interface IUser {
	phone: string
	name: string
	email: string
	address: string
	postalZip: string
	region: string
	country: string
	numberrange: number
	currency: string
}

export interface IUsersProps {
	users: IUser[]
}

export interface IUserCartProps {
	user: IUser
}

export interface IAddressProps {
	address: string
	postalZip: string
	region: string
	country: string
}

export enum ATTRIBUTE_VALUES {
	NAME = 'name',
	EMAIL = 'email',
	POSTAL_ZIP = 'postalZip',
}
